//
//  ScanInfo.m
//  Code
//
//  Created by Rohit Ranjan Pandey on 17/11/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ScanInfo.h"
#import "CommentView.h"
#import "AppManager.h"

@implementation ScanInfo

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
    }
    return self;
}

- (void)didReceiveMemoryWarning {
    
    [super didReceiveMemoryWarning];
}

#pragma mark - View lifecycle

- (void)viewDidLoad {
    
    [super viewDidLoad];
    self.navigationController.navigationBar.hidden = NO;
    self.navigationController.navigationBar.barStyle=UIBarStyleBlackOpaque;
    self.navigationItem.hidesBackButton=NO;
    
    NSString *urlString=[NSString stringWithFormat:@"%@",[[AppManager sharedManager] fileUrl]];
    NSURL *url=[NSURL URLWithString:urlString];
    [pdfView loadRequest:[NSURLRequest requestWithURL:url]];
    
    self.title=@"Resume";
    [[AppManager sharedManager] setComment:nil];
    activity = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
	[activity setCenter:CGPointMake(150,230)];
	[self.view addSubview:activity]; 
	
	indicatorlabel=[[[UILabel alloc]init]autorelease];
	indicatorlabel.frame=CGRectMake(117, 246, 78, 30);
	[self.view addSubview:indicatorlabel];
	indicatorlabel.backgroundColor=[UIColor clearColor];
	indicatorlabel.text=@"Loading...";
	indicatorlabel.font=[UIFont fontWithName:@"Helvetica-Bold" size:15];
	indicatorlabel.textColor=[UIColor blackColor];
    
    self.navigationItem.rightBarButtonItem=[[UIBarButtonItem alloc]initWithTitle:@"Logout" style:UIBarButtonItemStyleBordered target:self action:@selector(logOut)];
}

-(void)logOut {
    
    [self.navigationController popToRootViewControllerAnimated:NO];
}


- (void)webViewDidStartLoad:(UIWebView *)webView {
	
	activity.hidden= FALSE;    
	[activity startAnimating]; 
    indicatorlabel.hidden=FALSE;
}

- (void)webViewDidFinishLoad:(UIWebView *)webView  {
    
	activity.hidden= TRUE;     
	[activity stopAnimating];  
	indicatorlabel.hidden=TRUE;
}

-(void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error {
    
    activity.hidden= TRUE;     
	[activity stopAnimating];  
	indicatorlabel.hidden=TRUE;
}


-(IBAction)comment:(id)sender {
    
    CommentView *commentObj=[[CommentView alloc]initWithNibName:@"CommentView" bundle:nil];
    UINavigationController *navC=[[UINavigationController alloc]initWithRootViewController:commentObj];
    [self.navigationController presentModalViewController:navC animated:YES];
}

-(IBAction)accept:(id)sender {
    
    [self callAcceptResumeAPI];
}

-(IBAction)reject:(id)sender {
    
    [[AppManager sharedManager] setComment:nil];
    [[AppManager sharedManager] setTextFieldText:nil];
    [self.navigationController popToViewController:[[self.navigationController viewControllers] objectAtIndex:2] animated:YES];
}

-(void)callAcceptResumeAPI {
    
    if([[AppManager sharedManager] isNetConnected]==YES) {
        
        [[AppManager sharedManager] LoadingView];
        timer = [NSTimer scheduledTimerWithTimeInterval:20.0 target:self selector:@selector(removeLoading) userInfo:nil repeats:NO];
        
        NSLog(@"comment %@",[[AppManager sharedManager] comment]);
        
        NSString *urlstr=[NSString stringWithFormat:@"%@tag=accept_resume&resume_file=%@&event_id=%@&comments=%@&uid=%@",kbaseUrl,[[AppManager sharedManager] scannedCode],[[AppManager sharedManager] eventId],[[AppManager sharedManager] comment],[[AppManager sharedManager] userId]];
        urlstr=[urlstr stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        NSURL *url=[NSURL URLWithString:urlstr];
        NSLog(@"url %@",[NSURL URLWithString:urlstr]);
        NSURLRequest *urlRequest=[NSURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:30];
        
        AppManager *appObj=[[AppManager alloc]init];
        [appObj fetchDataWithRequest:urlRequest delegate:self didFinishSelector:@selector(profileApiCallResult:) didFailSelector:@selector(profileApiCallFail:)];    
        [urlRequest release];
        [appObj release];
        [[AppManager sharedManager] setComment:nil];
        [[AppManager sharedManager] setTextFieldText:nil];
    }
    else {
        
        UIAlertView *alertBox=[[UIAlertView alloc]initWithTitle:@"Unable to reach network"
                                                        message:@"Please connect your device to Internet." delegate:self
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil,nil];
        [alertBox show];
        alertBox.tag=1;
        [alertBox release];
        
    }
}

- (void)profileApiCallResult:(NSDictionary *)data {
    
    [[AppManager sharedManager] removeLoadingView];
    if(timer) {
        
        [timer invalidate];
        timer=nil;
        [timer release];
    }
    NSString *str=[NSString stringWithFormat:@"%@",[data valueForKey:@"success"]];
    if([str isEqualToString:@"1"]) {
        
        NSString *msgStr=[NSString stringWithFormat:@"%@",[data valueForKey:@"message"]];
        
        UIAlertView *alertBox=[[UIAlertView alloc]initWithTitle:@"Accept Resume"
                                                        message:msgStr delegate:self
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil,nil];
        [alertBox show];
        alertBox.tag=2;
        [alertBox release];
    }
    else {
        
        NSString *errorStr=[NSString stringWithFormat:@"%@",[data valueForKey:@"message"]];
        
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Accept Resume" message:errorStr delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
        [alert release];  
    }
}

- (void)profileApiCallFail:(NSError *)error {
    
    [[AppManager sharedManager] removeLoadingView];
    if(timer) {
        
        [timer invalidate];
        timer=nil;
        [timer release];
    }
    UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Error" message:[error localizedDescription] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];
    [alert release]; 
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    
    if(alertView.tag==2) {
        
        [self.navigationController popToViewController:[[self.navigationController viewControllers] objectAtIndex:2] animated:YES];
    }
        
}

-(void)removeLoading {
    
    [[AppManager sharedManager] removeLoadingView];
    if(timer) {
        
        [timer invalidate];
        timer=nil;
        [timer release];
    }
}

-(void)viewDidDisappear:(BOOL)animated {
    
    if(timer) {
        
        [timer invalidate];
        timer=nil;
        [timer release];
    }
}



- (void)viewDidUnload {
    
    [super viewDidUnload];
}


@end
