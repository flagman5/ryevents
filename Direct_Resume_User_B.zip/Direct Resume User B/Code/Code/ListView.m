//
//  ListView.m
//  Code
//
//  Created by Rohit Ranjan Pandey on 17/11/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#define EVENT_TITLE 1
#import "ListView.h"
#import "AppManager.h"
#import "ResumeDetail.h"

@implementation ListView

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
    
    }
    return self;
}

- (void)didReceiveMemoryWarning {
    
    [super didReceiveMemoryWarning];
}

#pragma mark - View lifecycle

- (void)viewDidLoad {
    
    [super viewDidLoad];
    self.navigationController.navigationBar.hidden = NO;
    self.navigationController.navigationBar.barStyle=UIBarStyleBlackOpaque;
    self.navigationItem.hidesBackButton=NO;
    
    UIBarButtonItem *doneBtn=[[UIBarButtonItem alloc]initWithTitle:@"Done" style:UIBarButtonItemStyleBordered target:self action:@selector(done)];
    self.navigationItem.rightBarButtonItem=doneBtn;
    
    listArray=[[NSMutableArray alloc]init];
    fileArray=[[NSMutableArray alloc]init];
}

-(void)viewWillAppear:(BOOL)animated {
    
    if([listArray count]>0)
        [listArray removeAllObjects];
    
     [self getAcceptedData];
}

-(void)getAcceptedData {
    
    if([[AppManager sharedManager] isNetConnected]==YES) {
        
        [[AppManager sharedManager] LoadingView];
        timer = [NSTimer scheduledTimerWithTimeInterval:20.0 target:self selector:@selector(removeLoading) userInfo:nil repeats:NO];
        
        NSString *urlstr=[NSString stringWithFormat:@"%@tag=get_total_acceptance&event_id=%@",kbaseUrl,[[AppManager sharedManager] eventId]];
        NSURL *url=[NSURL URLWithString:urlstr];
        NSLog(@"url %@",[NSURL URLWithString:urlstr]);
        NSURLRequest *urlRequest=[NSURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:30];
        
        AppManager *appObj=[[AppManager alloc]init];
        [appObj fetchDataWithRequest:urlRequest delegate:self didFinishSelector:@selector(profileApiCallResult:) didFailSelector:@selector(profileApiCallFail:)];    
        [urlRequest release];
        [appObj release];
        
    }
    else {
        
        UIAlertView *alertBox=[[UIAlertView alloc]initWithTitle:@"Unable to reach network"
                                                        message:@"Please connect your device to Internet." delegate:self
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil,nil];
        [alertBox show];
        alertBox.tag=1;
        [alertBox release];
    }
}

- (void)profileApiCallResult:(NSDictionary *)data {
    
    [[AppManager sharedManager] removeLoadingView];
    if(timer) {
        
        [timer invalidate];
        timer=nil;
        [timer release];
    }
    NSString *str=[NSString stringWithFormat:@"%@",[data valueForKey:@"success"]];
    if([str isEqualToString:@"1"]) {
        
        NSLog(@"data %@",data);
        NSMutableDictionary *listDict=[[NSMutableDictionary alloc]init];
        [listDict addEntriesFromDictionary:data];
        self.title=[NSString stringWithFormat:@"Total Resume (%@)",[listDict valueForKey:@"total"]];
        for(int i=0;i<[listDict count];i++) {
            
            NSString *str=[NSString stringWithFormat:@"user.%d",i];
        
            if([[listDict valueForKey:str] count]>i) {
                
                NSDictionary *dict=[listDict valueForKey:str];                
                [listArray addObject:dict];
            }
        }
        [listTable reloadData]; 
    }
    else {
        
        NSString *errorStr=[NSString stringWithFormat:@"%@",[data valueForKey:@"message"]];
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Accepted Resume" message:errorStr delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
        [alert release];  
        [listTable reloadData]; 
        self.title=[NSString stringWithFormat:@"Total Resume (%@)",@"0"];
    }
}

- (void)profileApiCallFailed:(NSError *)error {
    
    [[AppManager sharedManager] removeLoadingView];
    if(timer) {
        
        [timer invalidate];
        timer=nil;
        [timer release];
    }
    UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Error" message:[error localizedDescription] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];
    [alert release]; 
    [listTable reloadData]; 
    self.title=[NSString stringWithFormat:@"Total Resume (%@)",@"0"];
}

-(void)removeLoading {
    
    [[AppManager sharedManager] removeLoadingView];
    if(timer) {
        
        [timer invalidate];
        timer=nil;
        [timer release];
    }
}

-(void)viewDidDisappear:(BOOL)animated {
    
    if(timer) {
        
        [timer invalidate];
        timer=nil;
        [timer release];
    }
}


-(void)done {
    
    [self.navigationController dismissModalViewControllerAnimated:YES];
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath   {
    
    return 60;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    if([listArray count]>0)
        return [listArray count];    
    else
        return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	
    if ([listArray count] == 0) {
        
        UITableViewCell *cell = [[[UITableViewCell alloc] init] autorelease];
        cell.textLabel.text = @"No Record Found";
        cell.textLabel.font = [UIFont fontWithName:@"Helvetica"size:15];
        cell.textLabel.frame = CGRectMake(80, 5, 160, 20);
        cell.textLabel.textColor=[UIColor whiteColor];
        cell.textLabel.textAlignment = UITextAlignmentCenter;
        cell.userInteractionEnabled=NO;
        return cell;
    }
    
    static NSString *CellIdentifier = @"Cell"; 
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	if (cell == nil) {
		
		cell = [self tableviewCellWithReuseIdentifier:CellIdentifier];
		
	}
	[self configureCell:cell forIndexPath:indexPath];		
    return cell;
}

- (UITableViewCell *)tableviewCellWithReuseIdentifier:(NSString *)identifier {
	
	if([identifier isEqualToString:@"UICell"]){
		
		UITableViewCell *uiCell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
		uiCell.textLabel.textAlignment = UITextAlignmentCenter;
		uiCell.textLabel.font = [UIFont systemFontOfSize:16];
		return uiCell;
	}
	
	CGRect rect;
	rect = CGRectMake(0.0, 0.0, self.view.frame.size.width, 52.0);
	
	UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
	cell.selectionStyle =UITableViewCellSelectionStyleNone;
	    
	UILabel *Event_Title = [[UILabel alloc] initWithFrame:CGRectMake(40.0,14.0,600,30)];
	Event_Title.tag = EVENT_TITLE;
	Event_Title.font=[UIFont fontWithName:@"Helvetica-Bold"size:22];
	Event_Title.lineBreakMode = UILineBreakModeWordWrap;
	Event_Title.numberOfLines = 0;
	[Event_Title setTextColor:[UIColor blackColor]];
	[Event_Title	setBackgroundColor:[UIColor clearColor]];
	[cell.contentView addSubview:Event_Title];
	Event_Title.textAlignment=UITextAlignmentLeft;
	[Event_Title release];
	
	return cell;
}

- (void)configureCell:(UITableViewCell *)cell forIndexPath:(NSIndexPath *)indexPath {
    
    UILabel *e_Title = (UILabel *) [cell.contentView viewWithTag:EVENT_TITLE];
    e_Title.text=[[listArray objectAtIndex:indexPath.row] valueForKey:@"name"];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    ResumeDetail *detailObj=[[ResumeDetail alloc]initWithNibName:@"ResumeDetail" bundle:nil];
    detailObj.urlString=[NSString stringWithFormat:@"%@",[[listArray objectAtIndex:indexPath.row] valueForKey:@"url"]];
    detailObj.comment=[NSString stringWithFormat:@"%@",[[listArray objectAtIndex:indexPath.row] valueForKey:@"comments"]];
    detailObj.fileName=[NSString stringWithFormat:@"%@",[[listArray objectAtIndex:indexPath.row] valueForKey:@"resume_file"]];
    [self.navigationController pushViewController:detailObj animated:YES];
}

- (void)viewDidUnload {
    
    [super viewDidUnload];
}


@end
