//
//  CommentView.h
//  Code
//
//  Created by Rohit Ranjan Pandey on 17/11/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

@interface CommentView : UIViewController <UITextFieldDelegate> {
    
    IBOutlet UITextField *comment;
}

-(void)done ;
-(NSString *) stringByStrippingHTML:(NSString *)teststring;
@end
