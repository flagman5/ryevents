//
//  AppManager.h
//  Code
//
//  Created by Rohit Ranjan Pandey on 17/11/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#define kbaseUrl @"http://www.ryevents.com/mobile/index.php?"
#import <Foundation/Foundation.h>

@interface AppManager : NSObject {
    
    NSString *userId;
    NSString *comapnyName;
    NSString *eventName;
    NSString *eventId;
    NSString *scannedCode;
    NSString *fileUrl;
    NSString *comment;
    NSString *textFieldText;
    
    UIAlertView *av;
    NSURLRequest *request;
    NSURLResponse *response;
    NSURLConnection *connection;
    NSMutableData *responseData;
    id delegate;
    SEL didFinishSelector;
    SEL didFailSelector;
    
    BOOL isNetConnected;
}

@property(nonatomic,retain)NSString *textFieldText;
@property(assign)BOOL isNetConnected;
@property(nonatomic,retain)NSString *userId;
@property(nonatomic,retain)NSString *comapnyName;
@property(nonatomic,retain)NSString *eventName;
@property(nonatomic,retain) NSString *eventId;
@property(nonatomic,retain)NSString *scannedCode;
@property(nonatomic,retain)NSString *fileUrl;
@property(nonatomic,retain)NSString *comment;

+ (id)sharedManager;
- (void)fetchDataWithRequest:(NSURLRequest *)aRequest delegate:(id)aDelegate didFinishSelector:(SEL)finishSelector didFailSelector:(SEL)failSelector ;
-(void)LoadingView;
-(void)removeLoadingView ;
@end
