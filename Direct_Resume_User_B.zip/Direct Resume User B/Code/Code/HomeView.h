//
//  HomeView.h
//  Code
//
//  Created by Rohit Ranjan Pandey on 17/11/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZBarReaderController.h"

@class ZBarReaderController;

@interface HomeView : UIViewController <UIImagePickerControllerDelegate,UINavigationControllerDelegate,ZBarReaderDelegate> {
    
    IBOutlet UIButton *capture;
    IBOutlet UIButton *viewInfo;
    IBOutlet UIButton *end;
    NSTimer *timer;
    
    BOOL qrCodeScaned;
    NSString *scannedCode;
    UIImagePickerController *mImagePickerController;
}

-(IBAction)captureCall:(id)sender;
-(IBAction)viewCall:(id)sender;
-(IBAction)endCall:(id)sender;
-(void)callFetchResumeAPI ;
-(void)endEventAPiCall ;
@end
