//
//  ResumeDetail.h
//  Code
//
//  Created by Rohit Ranjan Pandey on 17/11/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

@interface ResumeDetail : UIViewController<UIWebViewDelegate> {
    
    IBOutlet UILabel *resumeLabel;
    IBOutlet UIWebView *pdfView;
    NSString *urlString;
    IBOutlet UILabel *commentLbl;
    IBOutlet UITextField *commentField;
    NSString *comment;
    NSString *fileName;
    IBOutlet UIButton *saveBtn;
    IBOutlet UIButton *deleteBtn;
    
    UIActivityIndicatorView *activity;
    UILabel		*indicatorlabel;
    NSTimer *timer;
    NSString *strValue;
}

@property(nonatomic,retain)    NSString *urlString;
@property(nonatomic,retain)    NSString *comment;
@property(nonatomic,retain)    NSString *fileName;

-(IBAction)saveresume:(id)sender;
-(IBAction)deleteresume:(id)sender;
-(void)deleteResumeApi;
-(void)setViewMovedUp:(BOOL)movedUp ;
-(void)updateApi;
-(NSString *) stringByStrippingHTML:(NSString *)teststring ;
@end

