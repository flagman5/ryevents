//
//  HomeView.m
//  Code
//
//  Created by Rohit Ranjan Pandey on 17/11/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "HomeView.h"
#import "ZBarReaderController.h"
#import "ZBarReaderViewController.h"
#import "AppManager.h"
#import "ScanInfo.h"
#import "ListView.h"


@implementation HomeView

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
    
    }
    return self;
}

- (void)didReceiveMemoryWarning {
    
    [super didReceiveMemoryWarning];
}

#pragma mark - View lifecycle

- (void)viewDidLoad {
    
    [super viewDidLoad];
    self.navigationController.navigationBar.hidden = NO;
    self.navigationController.navigationBar.barStyle=UIBarStyleBlackOpaque;
    self.navigationItem.hidesBackButton=NO;
    self.title=@"Home";
    self.navigationItem.rightBarButtonItem=[[UIBarButtonItem alloc]initWithTitle:@"Logout" style:UIBarButtonItemStyleBordered target:self action:@selector(logOut)];
}

-(void)logOut {
    
    [self.navigationController popToRootViewControllerAnimated:NO];
}

-(IBAction)captureCall:(id)sender {
    
    qrCodeScaned = NO;
    ZBarReaderViewController *reader = [ZBarReaderViewController new];
    reader.readerDelegate = self;
    reader.supportedOrientationsMask = ZBarOrientationMaskAll;
    
    ZBarImageScanner *scanner = reader.scanner;
    [scanner setSymbology: ZBAR_I25 config: ZBAR_CFG_ENABLE to: 0];
    [self presentModalViewController: reader animated: YES];

}


- (void) imagePickerController: (UIImagePickerController*) reader didFinishPickingMediaWithInfo: (NSDictionary*) info {
    
    id<NSFastEnumeration> results = [info objectForKey: ZBarReaderControllerResults];
    ZBarSymbol *symbol = nil;
    for(symbol in results) {
        
        [[AppManager sharedManager] setScannedCode:symbol.data];
        NSLog(@"the value of the scanned UPC is: %@",[[AppManager sharedManager] scannedCode]);
    }
    
    /*
     
     ADD HERE CODE TO SUBMIT THE SCANNED IDENTIFIER VALUE TO SERVER AND WAIT FOR RESPONSE.IF ERROR NO OPEARTION ,CAMERA PICKER WILL DISMISS AND USER WILL BACK ON HOME SCREEN.AND IF SUCCESS WILL GET RESPONSE AND WILL GO TO NEXT PAGE AFTER DISMISS THIS CAMERA PICKER.
     
     */
    [reader dismissModalViewControllerAnimated: YES];
    [self callFetchResumeAPI];
    [reader release];
}


-(IBAction)viewCall:(id)sender {
    
    ListView *listObj=[[ListView alloc]initWithNibName:@"ListView" bundle:nil];
    UINavigationController *navC=[[UINavigationController alloc]initWithRootViewController:listObj];
    [self.navigationController presentModalViewController:navC animated:YES];
}

-(IBAction)endCall:(id)sender {
    
    UIAlertView *alertBox=[[UIAlertView alloc]initWithTitle:@"End Event"
                                                    message:@"Are you sure,want to end event" delegate:self
                                          cancelButtonTitle:nil
                                          otherButtonTitles:@"YES",@"NO",nil];
    [alertBox show];
    alertBox.tag=2;
    [alertBox release];

}


- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    
    [picker dismissModalViewControllerAnimated: YES];
    
 //   [[AppManager sharedManager] setScannedCode:@"509947cebc0db9.68702234_2.pdf"];
 //   [self callFetchResumeAPI];
}

-(void)callFetchResumeAPI {
    
    if([[AppManager sharedManager] scannedCode]==nil) {
        
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"File Missing" message:@"Could not scan code properly." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
        [alert release];
    }
    else if([[AppManager sharedManager] isNetConnected]==YES) {
        
        [[AppManager sharedManager] LoadingView];
        timer = [NSTimer scheduledTimerWithTimeInterval:20.0 target:self selector:@selector(removeLoading) userInfo:nil repeats:NO];
        
        NSString *urlstr=[NSString stringWithFormat:@"%@tag=fetch_resume&resume_file=%@",kbaseUrl,[[AppManager sharedManager] scannedCode]];
        NSURL *url=[NSURL URLWithString:urlstr];
        NSLog(@"url %@",[NSURL URLWithString:urlstr]);
        NSURLRequest *urlRequest=[NSURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:60];
        
        AppManager *appObj=[[AppManager alloc]init];
        [appObj fetchDataWithRequest:urlRequest delegate:self didFinishSelector:@selector(profileApiCallResult:) didFailSelector:@selector(profileApiCallFail:)];    
        [urlRequest release];
        [appObj release];
        
    }
    else {
        
        UIAlertView *alertBox=[[UIAlertView alloc]initWithTitle:@"Unable to reach network"
                                                        message:@"Please connect your device to Internet." delegate:self
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil,nil];
        [alertBox show];
        alertBox.tag=1;
        [alertBox release];
        
    }
}


- (void)profileApiCallResult:(NSDictionary *)data {
    
    [[AppManager sharedManager] removeLoadingView];
    if(timer) {
        
        [timer invalidate];
        timer=nil;
        [timer release];
    }
    NSString *str=[NSString stringWithFormat:@"%@",[data valueForKey:@"success"]];
    if([str isEqualToString:@"1"]) {
        
        [[AppManager sharedManager] setFileUrl:[NSString stringWithFormat:@"%@",[data valueForKey:@"url"]]];
        ScanInfo *scanObj=[[ScanInfo alloc]initWithNibName:@"ScanInfo" bundle:nil];
        [self.navigationController pushViewController:scanObj animated:YES];
    }
    else {
        
        NSString *errorStr=[NSString stringWithFormat:@"%@",[data valueForKey:@"error_msg"]];
        
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Resume" message:errorStr delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
        [alert release];  
    }
}

- (void)profileApiCallFailed:(NSError *)error {
    
    [[AppManager sharedManager] removeLoadingView];
    if(timer) {
        
        [timer invalidate];
        timer=nil;
        [timer release];
    }
    UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Error" message:[error localizedDescription] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];
    [alert release]; 
}

-(void)endEventAPiCall {
    
    if([[AppManager sharedManager] isNetConnected]==YES) {
        
        [[AppManager sharedManager] LoadingView];
        timer = [NSTimer scheduledTimerWithTimeInterval:20.0 target:self selector:@selector(removeLoading) userInfo:nil repeats:NO];
        
        NSString *urlstr=[NSString stringWithFormat:@"%@tag=end_event&event_id=%@&uid=%@",kbaseUrl,[[AppManager sharedManager] eventId],[[AppManager sharedManager] userId]];
        NSURL *url=[NSURL URLWithString:urlstr];
        NSLog(@"url %@",[NSURL URLWithString:urlstr]);
        NSURLRequest *urlRequest=[NSURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:30];
        
        AppManager *appObj=[[AppManager alloc]init];
        [appObj fetchDataWithRequest:urlRequest delegate:self didFinishSelector:@selector(endeventApiCallResult:) didFailSelector:@selector(endeventApiCallFail:)];    
        [urlRequest release];
        [appObj release];
        
    }
    else {
        
        UIAlertView *alertBox=[[UIAlertView alloc]initWithTitle:@"Unable to reach network"
                                                        message:@"Please connect your device to Internet." delegate:self
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil,nil];
        [alertBox show];
        alertBox.tag=1;
        [alertBox release];
        
    }
}

- (void)endeventApiCallResult:(NSDictionary *)data {
    
    [[AppManager sharedManager] removeLoadingView];
    if(timer) {
        
        [timer invalidate];
        timer=nil;
        [timer release];
    }
    NSString *str=[NSString stringWithFormat:@"%@",[data valueForKey:@"success"]];
    if([str isEqualToString:@"1"]) {
        
        NSString *msgStr=[NSString stringWithFormat:@"%@",[data valueForKey:@"message"]];
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"End Event" message:msgStr delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
        alert.tag=1;
        [alert release];  
    }
    else {
        
        NSString *errorStr=[NSString stringWithFormat:@"%@",[data valueForKey:@"error_msg"]];
        
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"End Event" message:errorStr delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
        alert.tag=2;
        [alert release];  
    }
}


- (void)endeventApiCallFail:(NSError *)error {
    
    [[AppManager sharedManager] removeLoadingView];
    if(timer) {
        
        [timer invalidate];
        timer=nil;
        [timer release];
    }
    UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Error" message:[error localizedDescription] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];
    [alert release]; 
}

-(void)removeLoading {
    
    [[AppManager sharedManager] removeLoadingView];
    if(timer) {
        
        [timer invalidate];
        timer=nil;
        [timer release];
    }
}

-(void)viewDidDisappear:(BOOL)animated {
    
    if(timer) {
        
        [timer invalidate];
        timer=nil;
        [timer release];
    }
}


- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    
    if(alertView.tag==1) {
        
        [self.navigationController popViewControllerAnimated:YES];
    }
    if(alertView.tag==2) {
        
        if(buttonIndex==0)
            [self endEventAPiCall];
    }
}

- (void)viewDidUnload {
    
    [super viewDidUnload];
}



@end
