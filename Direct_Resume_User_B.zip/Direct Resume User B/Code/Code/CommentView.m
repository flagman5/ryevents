//
//  CommentView.m
//  Code
//
//  Created by Rohit Ranjan Pandey on 17/11/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "CommentView.h"
#import "AppManager.h"
#import "NSString_stripHtml.h"

@implementation NSString (NSString_Extended)

- (NSString *)urlencode {
    NSMutableString *output = [NSMutableString string];
    const unsigned char *source = (const unsigned char *)[self UTF8String];
    int sourceLen = strlen((const char *)source);
    for (int i = 0; i < sourceLen; ++i) {
        const unsigned char thisChar = source[i];
        if (thisChar == ' '){
            [output appendString:@"+"];
        } else if (thisChar == '.' || thisChar == '-' || thisChar == '_' || thisChar == '~' || 
                   (thisChar >= 'a' && thisChar <= 'z') ||
                   (thisChar >= 'A' && thisChar <= 'Z') ||
                   (thisChar >= '0' && thisChar <= '9')) {
            [output appendFormat:@"%c", thisChar];
        } else {
            [output appendFormat:@"%%%02X", thisChar];
        }
    }
    return output;
}

@end

@implementation CommentView

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
    }
    return self;
}

- (void)didReceiveMemoryWarning {
    
    [super didReceiveMemoryWarning];
}

#pragma mark - View lifecycle

- (void)viewDidLoad {
    
    [super viewDidLoad];
    self.navigationController.navigationBar.hidden = NO;
    self.navigationController.navigationBar.barStyle=UIBarStyleBlackOpaque;
    self.navigationItem.hidesBackButton=NO;
    
    UIBarButtonItem *doneBtn=[[UIBarButtonItem alloc]initWithTitle:@"Done" style:UIBarButtonItemStyleBordered target:self action:@selector(done)];
    self.navigationItem.rightBarButtonItem=doneBtn;
    
    comment.frame=CGRectMake(49,62,668,50);
    comment.layer.borderColor=[UIColor blackColor].CGColor;
    comment.layer.borderWidth=1.0;
    comment.text=[[AppManager sharedManager] textFieldText];
    self.title=@"Comment";
}

-(void)done {
    
    [self.navigationController dismissModalViewControllerAnimated:YES];
    if([comment.text isEqualToString:@""]) {
        
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Comment Missing" message:@"You have not entered the comment." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
        [alert release];
    }
    else {
        
        NSString* onlystring=[self stringByStrippingHTML:comment.text];
        [[AppManager sharedManager] setComment:onlystring]; 
        [[AppManager sharedManager] setTextFieldText:comment.text];
    }
}

-(NSString *) stringByStrippingHTML:(NSString *)teststring {
    
    NSString * encodedString = (NSString *)CFURLCreateStringByAddingPercentEscapes(
                                                                                   NULL,
                                                                                   (CFStringRef)teststring,
                                                                                   NULL,
                                                                                   (CFStringRef)@"!*'();:@&=+$,/?%#[]",
                                                                                   kCFStringEncodingUTF8 );
    return encodedString; 
}


- (void)viewDidUnload {
    
    [super viewDidUnload];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {	
	
	[textField resignFirstResponder];
	return YES;
}



@end
