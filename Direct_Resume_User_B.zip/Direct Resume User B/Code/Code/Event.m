//
//  Event.m
//  Code
//
//  Created by Rohit Ranjan Pandey on 17/11/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Event.h"
#import "HomeView.h"
#import "AppManager.h"

@implementation Event

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
    }
    return self;
}

- (void)didReceiveMemoryWarning {
    
    [super didReceiveMemoryWarning];
}

-(void)viewDidDisappear:(BOOL)animated {
    
    if(timer) {
        
        [timer invalidate];
        timer=nil;
        [timer release];
    }
}

#pragma mark - View lifecycle

- (void)viewDidLoad {
    
    [super viewDidLoad];
    self.navigationController.navigationBar.hidden = NO;
    self.navigationController.navigationBar.barStyle=UIBarStyleBlackOpaque;
    self.navigationItem.hidesBackButton=NO;
    self.navigationItem.rightBarButtonItem=[[UIBarButtonItem alloc]initWithTitle:@"Logout" style:UIBarButtonItemStyleBordered target:self action:@selector(logOut)];
    
    self.title=@"Event";
}

-(void)logOut {
    
    [self.navigationController popToRootViewControllerAnimated:NO];
}

-(IBAction)event:(id)sender {
    
    [eventText resignFirstResponder];
    if([eventText.text isEqualToString:@""]) {
        
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Event Missing" message:@"Enter event name." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
        [alert release];
    }
    else {
        
        if([[AppManager sharedManager] isNetConnected]==YES) {
            
            timer = [NSTimer scheduledTimerWithTimeInterval:20.0 target:self selector:@selector(removeLoading) userInfo:nil repeats:NO];
            
            [[AppManager sharedManager] LoadingView];
            
            NSString *strcmp=[[[AppManager sharedManager] comapnyName] stringByReplacingOccurrencesOfString:@" " withString:@"%20"];
            NSString *testEvent=[self stringByStrippingHTML:eventText.text];
            
            NSString *str=[NSString stringWithFormat:@"%@tag=input_event&company=%@&event=%@",kbaseUrl,strcmp,testEvent];
            str=[str stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
            NSURL *url=[NSURL URLWithString:str];
            NSLog(@"url %@",[NSURL URLWithString:str]);
            NSURLRequest *urlRequest=[NSURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:30];
            
            AppManager *appObj=[[AppManager alloc]init];
            [appObj fetchDataWithRequest:urlRequest delegate:self didFinishSelector:@selector(profileApiCallResult:) didFailSelector:@selector(profileApiCallFail:)];    
            [urlRequest release];
            [appObj release];
        }
        else {
            
            UIAlertView *alertBox=[[UIAlertView alloc]initWithTitle:@"Unable to reach network"
                                                            message:@"Please connect your device to Internet." delegate:self
                                                  cancelButtonTitle:@"OK"
                                                  otherButtonTitles:nil,nil];
            [alertBox show];
            alertBox.tag=1;
            [alertBox release];
            
        }        
    }
}

-(void)removeLoading {
    
    [[AppManager sharedManager] removeLoadingView];
    if(timer) {
        
        [timer invalidate];
        timer=nil;
        [timer release];
    }
}

- (void)profileApiCallResult:(NSDictionary *)data {
    
    [[AppManager sharedManager] removeLoadingView];
    if(timer) {
        
        [timer invalidate];
        timer=nil;
        [timer release];
    }
    NSString *str=[NSString stringWithFormat:@"%@",[data valueForKey:@"success"]];
    if([str isEqualToString:@"1"]) {
        
        [[AppManager sharedManager] setEventId:[NSString stringWithFormat:@"%@",[data valueForKey:@"event_id"]]];
        HomeView *homeObj=[[HomeView alloc]initWithNibName:@"HomeView" bundle:nil];
        [self.navigationController pushViewController:homeObj animated:YES];
    }
    else {
        
        NSString *errorStr=[NSString stringWithFormat:@"%@",[data valueForKey:@"error_msg"]];
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Error" message:errorStr delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
        [alert release];  
    }
    eventText.text=nil;
}

- (void)profileApiCallFail:(NSError *)error {
    
    [[AppManager sharedManager] removeLoadingView];
    if(timer) {
        
        [timer invalidate];
        timer=nil;
        [timer release];
    }
    UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Error" message:[error localizedDescription] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];
    [alert release]; 
    eventText.text=nil;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {	
	
	[textField resignFirstResponder];
	return YES;
}

-(NSString *) stringByStrippingHTML:(NSString *)teststring {
    
    NSString * encodedString = (NSString *)CFURLCreateStringByAddingPercentEscapes(
                                                                                   NULL,
                                                                                   (CFStringRef)teststring,
                                                                                   NULL,
                                                                                   (CFStringRef)@"!*'();:@&=+$,/?%#[]",
                                                                                   kCFStringEncodingUTF8 );
    return encodedString; 
}


- (void)viewDidUnload {
    
    [super viewDidUnload];
}

//Previous space trimming code
/*   
 NSString* nospacestring = [eventText.text stringByReplacingOccurrencesOfString:@" " withString:@"-"];
 NSArray *arr;
 BOOL check=YES;
 while (check) {
 
 arr=[nospacestring componentsSeparatedByString:@"--"];
 if([arr count]>1) {
 
 nospacestring=[nospacestring stringByReplacingOccurrencesOfString:@"--" withString:@"-"];
 }
 else 
 check=NO;
 }*/



@end
