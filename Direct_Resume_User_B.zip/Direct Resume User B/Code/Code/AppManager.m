//
//  AppManager.m
//  Code
//
//  Created by Rohit Ranjan Pandey on 17/11/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "AppManager.h"
#import "AFNetworking.h"

static AppManager *sharedMyManager = nil;
@implementation AppManager

@synthesize userId,comapnyName,eventName,eventId,scannedCode,fileUrl,comment,isNetConnected,textFieldText;

+ (id)sharedManager {
	
    @synchronized(self) {
        if(sharedMyManager == nil) {
            
			sharedMyManager = [[super allocWithZone:NULL] init];
		}
    }
    return sharedMyManager;
}

- (void)fetchDataWithRequest:(NSURLRequest *)aRequest delegate:(id)aDelegate didFinishSelector:(SEL)finishSelector didFailSelector:(SEL)failSelector {
    
    [request release];
	request = [aRequest retain];
    delegate = aDelegate;
    didFinishSelector = finishSelector;
    didFailSelector = failSelector;
    
    AFJSONRequestOperation *operation = [AFJSONRequestOperation JSONRequestOperationWithRequest:request success:^(NSURLRequest *request, NSHTTPURLResponse *response, id JSON) {
        
        [delegate performSelector:didFinishSelector withObject:(NSDictionary *)JSON];
    }
    failure:^(NSURLRequest *request, NSHTTPURLResponse *response, NSError *error, id JSON) {
                                                                                            
        NSLog(@"error %@",error);
        [delegate performSelector:didFailSelector withObject:(NSDictionary *)JSON];
    }];
    
    [operation start];
}

-(void)LoadingView {
    
    av=[[UIAlertView alloc] initWithTitle:@"Loading" message:@"" delegate:self cancelButtonTitle:nil otherButtonTitles:nil];
    UIActivityIndicatorView *ActInd=[[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    [ActInd startAnimating];
    [ActInd setFrame:CGRectMake(125, 50, 37, 37)];
    [av addSubview:ActInd];
    [av show];
}

-(void)removeLoadingView {
    
    [av dismissWithClickedButtonIndex:0 animated:YES];
    [av release];
    av=nil;
}


@end
