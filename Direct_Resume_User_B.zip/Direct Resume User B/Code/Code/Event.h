//
//  Event.h
//  Code
//
//  Created by Rohit Ranjan Pandey on 17/11/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Event : UIViewController <UITextFieldDelegate>{
    
    IBOutlet UITextField *eventText;
    NSTimer *timer;
}

-(IBAction)event:(id)sender;
-(NSString *) stringByStrippingHTML:(NSString *)teststring;
@end
