//
//  ResumeDetail.m
//  Code
//
//  Created by Rohit Ranjan Pandey on 17/11/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ResumeDetail.h"
#import "AppManager.h"

@implementation ResumeDetail
@synthesize urlString,comment,fileName;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
    
    }
    return self;
}

- (void)didReceiveMemoryWarning {
    
    [super didReceiveMemoryWarning];
}

#pragma mark - View lifecycle

- (void)viewDidLoad {
    
    [super viewDidLoad];
    self.navigationController.navigationBar.hidden = NO;
    self.navigationController.navigationBar.barStyle=UIBarStyleBlackOpaque;
    self.navigationItem.hidesBackButton=NO;
    
    NSString *urlstr=[NSString stringWithFormat:@"%@",urlString];
    NSURL *url=[NSURL URLWithString:urlstr];
    [pdfView loadRequest:[NSURLRequest requestWithURL:url]];
    
    self.title=@"Resume";
    activity = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
	[activity setCenter:CGPointMake(150,230)];
	[self.view addSubview:activity]; 
	
	indicatorlabel=[[[UILabel alloc]init]autorelease];
	indicatorlabel.frame=CGRectMake(117, 246, 78, 30);
	[self.view addSubview:indicatorlabel];
	indicatorlabel.backgroundColor=[UIColor clearColor];
	indicatorlabel.text=@"Loading...";
	indicatorlabel.font=[UIFont fontWithName:@"Helvetica-Bold" size:15];
	indicatorlabel.textColor=[UIColor blackColor];
    
    commentField.frame=CGRectMake(49,809,668,50);
    commentField.layer.borderColor=[UIColor blackColor].CGColor;
    commentField.layer.borderWidth=1.0;
    if([comment isEqualToString:@"(null)"]) {
        
        commentField.text=nil;
    }
    else {
        
        commentField.text=comment;
        strValue=comment;
    }
}

- (void)webViewDidStartLoad:(UIWebView *)webView {
	
	activity.hidden= FALSE;    
	[activity startAnimating]; 
    indicatorlabel.hidden=FALSE;
}

- (void)webViewDidFinishLoad:(UIWebView *)webView  {
    
	activity.hidden= TRUE;     
	[activity stopAnimating];  
	indicatorlabel.hidden=TRUE;
}

-(void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error {
    
    activity.hidden= TRUE;     
	[activity stopAnimating];  
	indicatorlabel.hidden=TRUE;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {	
	
    [self setViewMovedUp:NO];
	[textField resignFirstResponder];
	return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField {
    
     [self setViewMovedUp:YES];
}

-(IBAction)saveresume:(id)sender {
    
    if([strValue isEqualToString:commentField.text]) {
        
        UIAlertView *updateAlert=[[UIAlertView alloc]initWithTitle:@"Update Resume" message:@"You did not make any changes! To keep the resume and comments please go back to the previous menu." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [updateAlert show];
        [updateAlert release];
    }
    else {
        
        [self updateApi];
    }
}

-(IBAction)deleteresume:(id)sender {
    
    [self setViewMovedUp:NO];
    [commentField resignFirstResponder];
    UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Delete Resume" message:@"Are you sure, want to delete the resume" delegate:self cancelButtonTitle:nil otherButtonTitles:@"Yes",@"No", nil];
    [alert show];
    alert.tag=10;
    [alert release]; 
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    
    if(alertView.tag==10) {
        
        if(buttonIndex==0) {
        
            [self deleteResumeApi];
        }
    }
    else if(alertView.tag==2) {
        
        [self.navigationController popViewControllerAnimated:YES];
    }
    else if(alertView.tag==1||alertView.tag==3||alertView.tag==4) {
        
    }
}

-(void)deleteResumeApi {
    
    if([[AppManager sharedManager] isNetConnected]==YES) {
    
        [[AppManager sharedManager] LoadingView];
        timer = [NSTimer scheduledTimerWithTimeInterval:20.0 target:self selector:@selector(removeLoading) userInfo:nil repeats:NO];
        
        NSString *urlstr=[NSString stringWithFormat:@"%@tag=delete&resume_file=%@&event_id=%@",kbaseUrl,fileName,[[AppManager sharedManager] eventId]];
        
        urlstr=[urlstr stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        NSURL *url=[NSURL URLWithString:urlstr];
        NSLog(@"url %@",[NSURL URLWithString:urlstr]);
        NSURLRequest *urlRequest=[NSURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:30];
    
        AppManager *appObj=[[AppManager alloc]init];
        [appObj fetchDataWithRequest:urlRequest delegate:self didFinishSelector:@selector(profileApiCallResult:) didFailSelector:@selector(profileApiCallFail:)];    
        [urlRequest release];
        [appObj release];
    }
    else {
    
        UIAlertView *alertBox=[[UIAlertView alloc]initWithTitle:@"Unable to reach network"
                                                    message:@"Please connect your device to Internet." delegate:self
                                          cancelButtonTitle:@"OK"
                                          otherButtonTitles:nil,nil];
        [alertBox show];
        alertBox.tag=1;
        [alertBox release];
    }
}

- (void)profileApiCallResult:(NSDictionary *)data {
    
    [[AppManager sharedManager] removeLoadingView];
    if(timer) {
        
        [timer invalidate];
        timer=nil;
        [timer release];
    }
    NSString *str=[NSString stringWithFormat:@"%@",[data valueForKey:@"success"]];
    if([str isEqualToString:@"1"]) {
        
        NSString *msgStr=[NSString stringWithFormat:@"%@",[data valueForKey:@"message"]];
        
        UIAlertView *alertBox=[[UIAlertView alloc]initWithTitle:@"Delete Resume"
                                                        message:msgStr delegate:self
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil,nil];
        [alertBox show];
        alertBox.tag=2;
        [alertBox release];
        commentField.text=nil;
    }
    else {
        
        NSString *errorStr=[NSString stringWithFormat:@"%@",[data valueForKey:@"message"]];
        
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Delete Resume" message:errorStr delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
        alert.tag=3;
        [alert release];  
    }
}

- (void)profileApiCallFail:(NSError *)error {
    
    [[AppManager sharedManager] removeLoadingView];
    if(timer) {
        
        [timer invalidate];
        timer=nil;
        [timer release];
    }
    UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Error" message:[error localizedDescription] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];
    alert.tag=4;
    [alert release]; 
}

-(void)updateApi {
    
    [self setViewMovedUp:NO];
    [commentField resignFirstResponder];
    if([[AppManager sharedManager] isNetConnected]==YES) {
        
        [[AppManager sharedManager] LoadingView];
        timer = [NSTimer scheduledTimerWithTimeInterval:20.0 target:self selector:@selector(removeLoading) userInfo:nil repeats:NO];
        
        NSString *testComment=[self stringByStrippingHTML:commentField.text];
        
        NSString *urlstr=[NSString stringWithFormat:@"%@tag=make_changes&resume_file=%@&event_id=%@&comments=%@&uid=%@",kbaseUrl,fileName,[[AppManager sharedManager] eventId],testComment,[[AppManager sharedManager] userId]];
        
        urlstr=[urlstr stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        NSURL *url=[NSURL URLWithString:urlstr];
        NSLog(@"url %@",[NSURL URLWithString:urlstr]);
        NSURLRequest *urlRequest=[NSURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:30];
        
        AppManager *appObj=[[AppManager alloc]init];
        [appObj fetchDataWithRequest:urlRequest delegate:self didFinishSelector:@selector(updateApiCallResult:) didFailSelector:@selector(updateApiCallFail:)];    
        [urlRequest release];
        [appObj release];
    }
    else {
        
        UIAlertView *alertBox=[[UIAlertView alloc]initWithTitle:@"Unable to reach network"
                                                        message:@"Please connect your device to Internet." delegate:self
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil,nil];
        [alertBox show];
        alertBox.tag=1;
        [alertBox release];
    }
}

-(NSString *) stringByStrippingHTML:(NSString *)teststring {
    
    NSString * encodedString = (NSString *)CFURLCreateStringByAddingPercentEscapes(
                                                                                   NULL,
                                                                                   (CFStringRef)teststring,
                                                                                   NULL,
                                                                                   (CFStringRef)@"!*'();:@&=+$,/?%#[]",
                                                                                   kCFStringEncodingUTF8 );
    return encodedString; 
}

- (void)updateApiCallResult:(NSDictionary *)data {
    
    [[AppManager sharedManager] removeLoadingView];
    if(timer) {
        
        [timer invalidate];
        timer=nil;
        [timer release];
    }
    NSString *str=[NSString stringWithFormat:@"%@",[data valueForKey:@"success"]];
    if([str isEqualToString:@"1"]) {
        
        NSString *msgStr=[NSString stringWithFormat:@"%@",[data valueForKey:@"message"]];
        
        UIAlertView *alertBox=[[UIAlertView alloc]initWithTitle:@"Update Resume"
                                                        message:msgStr delegate:self
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil,nil];
        [alertBox show];
        alertBox.tag=2;
        [alertBox release];
        commentField.text=nil;
    }
    else {
        
        NSString *errorStr=[NSString stringWithFormat:@"%@",[data valueForKey:@"message"]];
        if([errorStr isEqualToString:@"(null)"])
            errorStr=@"You did not make any changes! To keep the resume and comments please go back to the previous menu.";
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Update Resume" message:errorStr delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
        alert.tag=3;
        [alert release];  
    }
}

- (void)updateApiCallFail:(NSError *)error {
    
    [[AppManager sharedManager] removeLoadingView];
    if(timer) {
        
        [timer invalidate];
        timer=nil;
        [timer release];
    }
    UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Error" message:[error localizedDescription] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];
    alert.tag=4;
    [alert release]; 
}

-(void)setViewMovedUp:(BOOL)movedUp {
    
	[UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.3]; 
	
    if (movedUp) {
        
        resumeLabel.frame=CGRectMake(62,-160,282,38);
        pdfView.frame = CGRectMake(61,-197,653,732);
		commentLbl.frame = CGRectMake(61,526,94,36);
		commentField.frame =CGRectMake(61,559,668,50);
        saveBtn.frame=CGRectMake(206,626,130,37);
        deleteBtn.frame=CGRectMake(420,626,130,37);
    }
    else {
        
        resumeLabel.frame=CGRectMake(62,10,282,38);
        pdfView.frame = CGRectMake(61,53,653,732);
		commentLbl.frame = CGRectMake(61,776,94,36);
		commentField.frame =CGRectMake(49,809,668,50);
        saveBtn.frame=CGRectMake(206,876,130,37);
        deleteBtn.frame=CGRectMake(420,876,130,37);
    }
    [UIView commitAnimations];
}

-(void)viewDidDisappear:(BOOL)animated {
    
     [self setViewMovedUp:NO];
    [commentField resignFirstResponder];
}

- (void)viewDidUnload {
    
    [super viewDidUnload];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {

	return YES;
}

@end
