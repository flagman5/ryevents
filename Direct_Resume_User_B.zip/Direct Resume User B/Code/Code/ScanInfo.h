//
//  ScanInfo.h
//  Code
//
//  Created by Rohit Ranjan Pandey on 17/11/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ScanInfo : UIViewController {
    
    IBOutlet UIButton *commentBtn;
    IBOutlet UIButton *acceptBtn;
    IBOutlet UIButton *rejectBtn;
    NSTimer *timer;
    
    IBOutlet UIWebView *pdfView;
    UIActivityIndicatorView *activity;
    UILabel		*indicatorlabel;
}

-(IBAction)comment:(id)sender;
-(IBAction)accept:(id)sender;
-(IBAction)reject:(id)sender;
-(void)callAcceptResumeAPI ;
@end
