//
//  ViewController.h
//  Code
//
//  Created by Rohit Ranjan Pandey on 17/11/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITextFieldDelegate> {
    
    IBOutlet UITextField *email;
    IBOutlet UITextField *password;
    IBOutlet UIButton *loginBtn;
}

-(IBAction)login:(id)sender;
@end
