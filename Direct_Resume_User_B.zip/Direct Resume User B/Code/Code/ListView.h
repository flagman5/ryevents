//
//  ListView.h
//  Code
//
//  Created by Rohit Ranjan Pandey on 17/11/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ListView : UIViewController <UITableViewDelegate,UITableViewDataSource> {
    
    IBOutlet UITableView *listTable;
    NSMutableArray *listArray;
    NSMutableArray *fileArray;
    NSTimer *timer;
}

- (UITableViewCell *)tableviewCellWithReuseIdentifier:(NSString *)identifier;
- (void)configureCell:(UITableViewCell *)cell forIndexPath:(NSIndexPath *)indexPath;
-(void)done ;
-(void)getAcceptedData;
@end
