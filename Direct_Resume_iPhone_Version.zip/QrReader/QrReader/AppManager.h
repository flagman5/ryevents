//
//  AppManager.h
//  QrReader
//
//  Created by Rohit Ranjan Pandey on 17/11/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AppManager : NSObject {
    
    NSURLRequest *request;
    NSURLResponse *response;
    NSURLConnection *connection;
    NSMutableData *responseData;
    id delegate;
    SEL didFinishSelector;
    SEL didFailSelector;
    
    NSString *uid;
    UIAlertView *av;
    BOOL isNetConnected;
}
@property(nonatomic,retain)    NSString *uid;
@property(assign)BOOL isNetConnected;

+ (id)sharedManager ;
- (void)fetchDataWithRequest:(NSURLRequest *)aRequest delegate:(id)aDelegate didFinishSelector:(SEL)finishSelector didFailSelector:(SEL)failSelector;
-(void)LoadingView;
-(void)removeLoadingView;
@end
