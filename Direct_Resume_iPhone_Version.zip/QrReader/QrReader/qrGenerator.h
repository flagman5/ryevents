//
//  qrGenerator.h
//  QrReader
//
//  Created by Rohit Ranjan Pandey on 17/11/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MessageUI/MessageUI.h>

@interface qrGenerator : UIViewController<MFMailComposeViewControllerDelegate> {
    
    UIImageView *QrCode;
    
    NSString *codeStr;
}
@property(nonatomic,retain)    NSString *codeStr;
-(void)createQRcode ;

@end
