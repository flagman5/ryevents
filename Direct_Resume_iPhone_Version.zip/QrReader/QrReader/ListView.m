//
//  ListView.m
//  Event
//
//  Created by Rohit Ranjan Pandey on 17/11/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#define EVENT_IMAGE 1
#define EVENT_TITLE 2
#define EVENT_SUBTITLE 3

#import "ListView.h"
#import "qrGenerator.h"
#import "Helper.h"
#import "AppManager.h"
#import "AppDelegate.h"

@implementation ListView

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
    
    }
    return self;
}

- (void)didReceiveMemoryWarning {
    
    [super didReceiveMemoryWarning];
}

#pragma mark - View lifecycle

- (void)viewDidLoad {
    
    [super viewDidLoad];
    self.navigationController.navigationBarHidden=NO;
    self.navigationController.navigationBar.barStyle=UIBarStyleBlackOpaque;
    self.title=@"Student";
    self.navigationItem.hidesBackButton=YES;
    UIBarButtonItem *logoutBtn =[[UIBarButtonItem alloc] initWithTitle:@"Logout" style:UIBarButtonItemStyleBordered target:self action:@selector(logOut)];
	self.navigationItem.rightBarButtonItem=logoutBtn;

    listDict=[[NSMutableDictionary alloc]init];
    listArray=[[NSMutableArray alloc]init];
    listArr=[[NSMutableArray alloc]init];
    if([[AppManager sharedManager] isNetConnected]==YES) {
        
        [self callAPI];
    }
    else {
        
        UIAlertView *alertBox=[[UIAlertView alloc]initWithTitle:@"Unable to reach network"
                                                        message:@"Please connect your device to Internet." delegate:self
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil,nil];
        [alertBox show];
        alertBox.tag=1;
        [alertBox release];
 
    }
    [listTable reloadData];
}

-(void)logOut {

    [self.navigationController popToRootViewControllerAnimated:NO];
}

-(void)callAPI {
    
    NSString *urlstr=[NSString stringWithFormat:@"%@tag=list_resume&uid=%@",kbaseUrl,[[AppManager sharedManager]uid]];
    NSURL *url=[NSURL URLWithString:urlstr];
    NSURLRequest *urlRequest=[NSURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:30];
    
    AppManager *appObj=[[AppManager alloc]init];
    [appObj fetchDataWithRequest:urlRequest delegate:self didFinishSelector:@selector(profileApiCallResult:) didFailSelector:@selector(profileApiCallFail:)];    
    [urlRequest release];
    [appObj release];

}

- (void)profileApiCallResult:(NSDictionary *)data {
    
    NSString *str=[NSString stringWithFormat:@"%@",[data valueForKey:@"success"]];
    if([str isEqualToString:@"1"]) {
        
        if([listArray count]>0)
            [listArray removeAllObjects];
        if([listArr count]>0)
            [listArr removeAllObjects];
        
        [listDict addEntriesFromDictionary:data];
        for(int i=0;i<[listDict count];i++) {
            
            NSString *str=[NSString stringWithFormat:@"resume.%d",i];
            if([[listDict valueForKey:str] count]>0) {
                
                NSDictionary *dict=[listDict valueForKey:str];
                if(![[dict valueForKey:@"resume_file"] isEqualToString:@""])
                    [listArray addObject:[NSString stringWithFormat:@"%@",[dict valueForKey:@"resume_file"]]];
                if(![[dict valueForKey:@"resume_name"] isEqualToString:@""])
                    [listArr addObject:[NSString stringWithFormat:@"%@",[dict valueForKey:@"resume_name"]]];
            }
        }
        [listTable reloadData];
        [[AppManager sharedManager] removeLoadingView];
    }
    else {
        
        [[AppManager sharedManager] removeLoadingView];
        NSString *errorStr=[NSString stringWithFormat:@"%@",[data valueForKey:@"error_msg"]];
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Error" message:errorStr delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
        [alert release];
    }
}

- (void)profileApiCallFailed:(NSError *)error {

    [[AppManager sharedManager] removeLoadingView];
    UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Error" message:[error localizedDescription] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];
    [alert release];
}


-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath   {
    
    return 75;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return [listArray count];    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	
    if ([listArray count] == 0) {
        
        UITableViewCell *cell = [[[UITableViewCell alloc] init] autorelease];
        cell.textLabel.text = @"No data yet";
        cell.textLabel.font = [UIFont fontWithName:@"Helvetica"size:15];
        cell.textLabel.frame = CGRectMake(80, 5, 160, 20);
        cell.textLabel.textColor=[UIColor whiteColor];
        cell.textLabel.textAlignment = UITextAlignmentCenter;
        cell.userInteractionEnabled=NO;
        return cell;
    }
    
    static NSString *CellIdentifier = @"Cell"; 
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	if (cell == nil) {
		
		cell = [self tableviewCellWithReuseIdentifier:CellIdentifier];
		
	}
	[self configureCell:cell forIndexPath:indexPath];		
    return cell;
}

- (UITableViewCell *)tableviewCellWithReuseIdentifier:(NSString *)identifier {
	
	if([identifier isEqualToString:@"UICell"]){
		
		UITableViewCell *uiCell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
		uiCell.textLabel.textAlignment = UITextAlignmentCenter;
		uiCell.textLabel.font = [UIFont systemFontOfSize:16];
		return uiCell;
	}
	
	CGRect rect;
	rect = CGRectMake(0.0, 0.0, self.view.frame.size.width, 52.0);
	
	UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
	cell.selectionStyle =UITableViewCellSelectionStyleNone;
	
    UIImageView *profileImg=[[UIImageView alloc]init];
    profileImg.frame=CGRectMake(10,10,48,48);
    [cell.contentView addSubview:profileImg];
    profileImg.image=[UIImage imageNamed:kgreyImage];
    [profileImg release];
    
//	UILabel *Event_Title = [[UILabel alloc] initWithFrame:CGRectMake(70.0,15.0,245,20)];
//	Event_Title.tag = EVENT_TITLE;
//	Event_Title.font=[UIFont fontWithName:@"Helvetica-Bold"size:15];
//	Event_Title.lineBreakMode = UILineBreakModeWordWrap;
//	Event_Title.numberOfLines = 0;
//	[Event_Title setTextColor:[UIColor whiteColor]];
//	[Event_Title	setBackgroundColor:[UIColor clearColor]];
//	[cell.contentView addSubview:Event_Title];
//	Event_Title.textAlignment=UITextAlignmentLeft;
//	[Event_Title release];
	
	UILabel *Event_SubTitle = [[UILabel alloc] initWithFrame:CGRectMake(70.0,15.0,245,40)];
	Event_SubTitle.tag = EVENT_SUBTITLE;
	Event_SubTitle.font=[UIFont fontWithName:@"Helvetica"size:15];
	Event_SubTitle.lineBreakMode = UILineBreakModeWordWrap;
	Event_SubTitle.numberOfLines = 0;
	[Event_SubTitle setTextColor:[UIColor whiteColor]];
	[Event_SubTitle	setBackgroundColor:[UIColor clearColor]];
	[cell.contentView addSubview:Event_SubTitle];
	Event_SubTitle.textAlignment=UITextAlignmentLeft;
	[Event_SubTitle release];
	
	return cell;
    
}

- (void)configureCell:(UITableViewCell *)cell forIndexPath:(NSIndexPath *)indexPath {
    
//    UILabel *e_Title = (UILabel *) [cell.contentView viewWithTag:EVENT_TITLE];
//    e_Title.text=[listArray objectAtIndex:indexPath.row];
    
    UILabel *e_subTitle=(UILabel *)[cell.contentView viewWithTag:EVENT_SUBTITLE];
    e_subTitle.text=[listArr objectAtIndex:indexPath.row];
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
 
    qrGenerator *qrObj=[[qrGenerator alloc]initWithNibName:nil bundle:nil];
    qrObj.codeStr=[NSString stringWithFormat:@"%@",[listArr objectAtIndex:indexPath.row]];
    [self.navigationController pushViewController:qrObj animated:YES];
}

- (void)viewDidUnload {
    
    [super viewDidUnload];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
