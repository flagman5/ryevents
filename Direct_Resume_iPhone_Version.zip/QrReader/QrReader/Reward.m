//
//  Reward.m
//  BusinessApp
//
//  Created by Signity on 11/04/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Reward.h"
#import "ScanQrCode.h"

@implementation Reward{}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

/*
 // Implement loadView to create a view hierarchy programmatically, without using a nib.
 - (void)loadView
 {
 }
 */

- (void)viewWillAppear:(BOOL)animated
{
    
    self.navigationController.navigationBarHidden=YES;
    // NSLog(@"qrCodePage:%@",qrCodePage.counter);
    
    if(qrCodePage.qrCodeScaned)
    {
        rewardCounter =  [qrCodePage.counter intValue];
        qrCodePage.qrCodeScaned=NO;
        [self displayHeartResult];
    }
    
    //[self.view reloadInputViews];
}


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor clearColor];
    
    qrCodePage = [[ScanQrCode alloc]initWithNibName:@"ScanQrCode" bundle:nil];
    
    
    UIImage *img=[UIImage imageNamed:@""];
    imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, img.size.width,img.size.height)];
    imageView.image =img;
    imageView.userInteractionEnabled = YES;
    [self.view addSubview:imageView];
    
    UILabel *barLbl2=[[UILabel alloc] initWithFrame:CGRectMake(100, 0, 220, 44)];
    barLbl2.backgroundColor=[UIColor clearColor];
    barLbl2.textColor=[UIColor whiteColor];
    barLbl2.font=[UIFont fontWithName:@"TrebuchetMS-Bold" size:20];
    barLbl2.text=@"Rewards";
    [imageView addSubview:barLbl2]; 
    
    
    UIImage *barImg=[UIImage imageNamed:@""];
    imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 369, barImg.size.width,barImg.size.height)];
    imageView.image =barImg;
    imageView.userInteractionEnabled = YES;
    [self.view addSubview:imageView];
    
    
    UIButton *camImgBtn = [[UIButton alloc] initWithFrame:CGRectMake(120, 375, 81, 33)];
    [camImgBtn setBackgroundImage:[UIImage imageNamed: @""] forState:UIControlStateNormal];
    [camImgBtn setBackgroundImage:[UIImage imageNamed: @""] forState:UIControlStateHighlighted];
    camImgBtn.showsTouchWhenHighlighted = YES;
    [camImgBtn addTarget:self action:@selector(camImgBtnActn) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:camImgBtn];
    [camImgBtn release];
    
    
    UIImage *backgroundImage=[UIImage imageNamed:@""];
    backImage = [[UIImageView alloc] initWithFrame:CGRectMake(0, 45, 320,325)];
    backImage.image =backgroundImage;
    backImage.userInteractionEnabled = YES;
    [self.view addSubview:backImage];
    
    UILabel *pointTextLbl=[[UILabel alloc] initWithFrame:CGRectMake(50,240, 300, 44)];
    pointTextLbl.backgroundColor=[UIColor clearColor];
    pointTextLbl.font = [UIFont boldSystemFontOfSize:20];
    pointTextLbl.text=@"You only need";
    [backImage addSubview:pointTextLbl];
    
    pointLbl=[[UILabel alloc] initWithFrame:CGRectMake(195,240, 300, 44)];
    pointLbl.backgroundColor=[UIColor clearColor];
    pointLbl.font = [UIFont boldSystemFontOfSize:20];
    pointLbl.text=@"_ more";
    [backImage addSubview:pointLbl];
    
    rewardNameLabel=[[UILabel alloc] initWithFrame:CGRectMake(10,0, 300, 44)];
    rewardNameLabel.backgroundColor=[UIColor clearColor];
    rewardNameLabel.font = [UIFont boldSystemFontOfSize:20];
    //rewardNameLabel.text=@"Hello";
    [backImage addSubview:rewardNameLabel];
    
    
    UILabel *barLbl=[[UILabel alloc] initWithFrame:CGRectMake(25,280, 300, 44)];
    barLbl.backgroundColor=[UIColor clearColor];
    barLbl.font = [UIFont boldSystemFontOfSize:20];
    barLbl.text=@"scans to claim your reward";
    [backImage addSubview:barLbl];
    
    
    scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 80, 320, 220)]; 
    scrollView.backgroundColor = [UIColor clearColor];
	//scrollView.contentSize = CGSizeMake(200, 100);
	[scrollView setUserInteractionEnabled:TRUE];
	[scrollView setScrollEnabled:TRUE];
	[self.view addSubview:scrollView];
    [scrollView setShowsVerticalScrollIndicator:NO];
	[scrollView setShowsHorizontalScrollIndicator:NO];
    
    
    [self qrCodeClicked];
    
    [self rewardApiForCounterAndImage];
    
    
}


-(void)camImgBtnActn
{
    
    [self.navigationController pushViewController:qrCodePage animated:YES];
    
}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(void)qrCodeClicked
{
    
}


-(void)displayHeartResult
{
    int x =  40;
    int y = 20;
    
    for(int i = 0 ; i < rewardCounter; i++)
    {
        imageView = [[UIImageView alloc]init];
        
        
        if((i%3==0)&&(i!=0))
        {
            y=y+77;
            x=40;
        }
        else
            if(i!=0)
            {
                x=x+105;
            }
        imageView.frame = CGRectMake(x, y, rewardImage.size.width,rewardImage.size.height-5);
        
        imageView.image =rewardImage;
        imageView.userInteractionEnabled = YES;
        [scrollView addSubview:imageView];
    }
    
    if(rewardCounter==0)
    {
        pointLbl.text=[NSString stringWithFormat:@"%d more",totalScanCounter];
    }
    else
    {
        pointLbl.text=[NSString stringWithFormat:@"%d more",totalScanCounter-rewardCounter];
    }
    
    NSLog(@"pointLbl.text:%@",pointLbl.text);
    
    //rewardCounter=9;
    if((rewardCounter==totalScanCounter)&&(rewardCounter!=0))
    {
        rewardNameLabel.text = [NSString stringWithFormat:@"You Won: %@",rewardName];
        NSString *alertTitle = [NSString stringWithFormat:@"Congrats you won %@!",rewardName];
        NSString *alertBody = [NSString stringWithFormat:@"You have gained %d reward points. Show this message at the counter to claim your reward.",totalScanCounter];
        
        //imageView.image =nil;
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:alertTitle message:alertBody delegate:self cancelButtonTitle:@"Claim and Reset" otherButtonTitles:nil,nil]; 
        alert.tag = 2;
        [alert show];
        [alert release];  
    }
    
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(alertView.tag==2)
    {
        [self claimApiLaunched];
    }
    
}

-(void)claimApiLaunched
{
}



@end
