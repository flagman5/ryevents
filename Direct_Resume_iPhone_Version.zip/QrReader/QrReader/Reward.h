//
//  Reward.h
//  BusinessApp
//
//  Created by Signity on 11/04/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
@class ScanQrCode;

@interface Reward : UIViewController{
    
    UIImageView *imageView;
    ScanQrCode *qrCodePage;
    UILabel *pointLbl;
    UILabel *rewardNameLabel;
    
    int rewardCounter;
    int totalScanCounter;
    
    UIImageView *backImage;
    
    UIImage *rewardImage;
    
    NSString *rewardName;
    
    UIScrollView *scrollView;
    
    UIAlertView *av;
    
}

-(void)qrCodeClicked;
-(void)qrCodeRequestCallback:(id)responseDict;
-(void)displayHeartResult;
-(void)claimApiLaunched;
-(void)claimRequestCallback:(id)responseDict;
-(void)rewardApiForCounterAndImage;
-(void)counterRequestCallback:(id)responseDict;

-(void)LoadingView;
-(void)removeLoadingView;

@end

