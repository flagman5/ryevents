//
//  qrGenerator.m
//  QrReader
//
//  Created by Rohit Ranjan Pandey on 17/11/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "qrGenerator.h"
#import "Barcode.h"
#import <QuartzCore/QuartzCore.h>

@implementation qrGenerator
@synthesize codeStr;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
    
    }
    return self;
}

- (void)didReceiveMemoryWarning {
    
    [super didReceiveMemoryWarning];
}

#pragma mark - View lifecycle


- (void)viewDidLoad {
    
    [super viewDidLoad];
    self.navigationController.navigationBarHidden=NO;
    self.navigationController.navigationBar.barStyle=UIBarStyleBlackOpaque;
    self.view.backgroundColor=[UIColor whiteColor];
    self.title=@"QR Code";
    self.navigationItem.hidesBackButton=NO;
    UIBarButtonItem *logoutBtn =[[UIBarButtonItem alloc] initWithTitle:@"Logout" style:UIBarButtonItemStyleBordered target:self action:@selector(logOut)];
	self.navigationItem.rightBarButtonItem=logoutBtn;

    [self createQRcode];
}

-(void)logOut {
    
    [self.navigationController popToRootViewControllerAnimated:NO];
}


-(void)createQRcode {
    
    QrCode=[[UIImageView alloc]initWithFrame:CGRectMake(30, 60, 260, 260)];
    [QrCode.layer setBorderColor: [[UIColor blackColor] CGColor]];
    [QrCode.layer setBorderWidth: 2.0];   
    Barcode *barcode = [[Barcode alloc] init];
    [barcode setupQRCode:codeStr];
    QrCode.image = barcode.qRBarcode;
    [self.view addSubview:QrCode];
}

#pragma mark Dismiss Mail view controller

- (void)viewDidUnload {
    
    [super viewDidUnload];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {

    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
