//
//  AppManager.m
//  QrReader
//
//  Created by Rohit Ranjan Pandey on 17/11/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "AppManager.h"
#import "AFNetworking.h"

static AppManager *appManager = nil;
@implementation AppManager
@synthesize uid;
@synthesize isNetConnected;

- (void)fetchDataWithRequest:(NSURLRequest *)aRequest delegate:(id)aDelegate didFinishSelector:(SEL)finishSelector didFailSelector:(SEL)failSelector {
    
    [request release];
	request = [aRequest retain];
    delegate = aDelegate;
    didFinishSelector = finishSelector;
    didFailSelector = failSelector;
    
    AFJSONRequestOperation *operation = [AFJSONRequestOperation JSONRequestOperationWithRequest:request success:^(NSURLRequest *request, NSHTTPURLResponse *response, id JSON) {
        
        [delegate performSelector:didFinishSelector withObject:(NSDictionary *)JSON];
    }
    failure:^(NSURLRequest *request, NSHTTPURLResponse *response, NSError *error, id JSON) {
                                                                                            
        NSLog(@"error %@",error);
    }];
    
    [operation start];
}

+ (id)sharedManager {
	
    @synchronized(self) {
        if(appManager == nil) {
            
			appManager = [[super allocWithZone:NULL] init];
		}
    }
    return appManager;
}

-(void)LoadingView {
    
    av=[[UIAlertView alloc] initWithTitle:@"Getting Resumes List." message:@"" delegate:self cancelButtonTitle:nil otherButtonTitles:nil];
    UIActivityIndicatorView *ActInd=[[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    [ActInd startAnimating];
    [ActInd setFrame:CGRectMake(125, 50, 37, 37)];
    [av addSubview:ActInd];
    [av show];
}

-(void)removeLoadingView {
    
    [av dismissWithClickedButtonIndex:0 animated:YES];
    [av release];
    av=nil;
}


@end
