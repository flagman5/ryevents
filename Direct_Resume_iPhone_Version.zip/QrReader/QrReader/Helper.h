//
//  Helper.h
//  QrReader
//
//  Created by Rohit Ranjan Pandey on 17/11/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#ifndef QrReader_Helper_h
#define QrReader_Helper_h



#endif

#define kbaseUrl @"http://www.ryevents.com/mobile/index.php?"


#define kgreyImage @"boxgrey.png"