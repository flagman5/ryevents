//
//  AppDelegate.h
//  codereader
//
//  Created by BEYOND COMPUTER on 17/05/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Reachability.h"

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>{
    
	UINavigationController *navbar;
    ViewController *viewController;
    Reachability *objReachability;
}

@property (retain, nonatomic) UIWindow *window;

@property (retain, nonatomic) ViewController *viewController;
@property (nonatomic, retain) UINavigationController *navbar;


@end
