//
//  ViewController.m
//  codereader
//
//  Created by Rohit Ranjan Pandey on 17/11/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"
#import "ListView.h"
#import "Helper.h"
#import "AppManager.h"

@implementation ViewController

- (void)didReceiveMemoryWarning {
    
    [super didReceiveMemoryWarning];
}

#pragma mark - View lifecycle

- (void)viewDidLoad {
    
    [super viewDidLoad];
    self.navigationController.navigationBar.hidden = NO;
    self.navigationController.navigationBar.barStyle=UIBarStyleBlackOpaque;
    self.title=@"Direct Resume Login";
}

-(IBAction)login:(id)sender {
    
    if([email.text isEqualToString:@""]) {
        
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Email Missing" message:@"Enter email." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
        [alert release];
    }
    else if([password.text isEqualToString:@""]) {
        
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Password Missing" message:@"Enter password." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
        [alert release]; 
    }
    else {
    
        if([[AppManager sharedManager] isNetConnected]==YES) {
            
        [[AppManager sharedManager] LoadingView];
        NSString *urlstr=[NSString stringWithFormat:@"%@tag=login&email=%@&password=%@&type=student",kbaseUrl,email.text,password.text];
        NSURL *url=[NSURL URLWithString:urlstr];
        NSURLRequest *urlRequest=[NSURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:30];
    
        AppManager *appObj=[[AppManager alloc]init];
        [appObj fetchDataWithRequest:urlRequest delegate:self didFinishSelector:@selector(profileApiCallResult:) didFailSelector:@selector(profileApiCallFail:)];    
        [urlRequest release];
        [appObj release];
            
        }
        else {
            
            UIAlertView *alertBox=[[UIAlertView alloc]initWithTitle:@"Unable to reach network"
                                                            message:@"Please connect your device to Internet." delegate:self
                                                  cancelButtonTitle:@"OK"
                                                  otherButtonTitles:nil,nil];
            [alertBox show];
            alertBox.tag=1;
            [alertBox release];
            
        }

    }
}

- (void)profileApiCallResult:(NSDictionary *)data {
      
    NSString *str=[NSString stringWithFormat:@"%@",[data valueForKey:@"success"]];
    if([str isEqualToString:@"1"]) {
        
        [[AppManager sharedManager] setUid:[NSString stringWithFormat:@"%@",[data valueForKey:@"uid"]]];
        ListView *listObj=[[ListView alloc]initWithNibName:@"ListView" bundle:nil];
        [self.navigationController pushViewController:listObj animated:YES];
    }
    else {
        
        NSString *errorStr=[NSString stringWithFormat:@"%@",[data valueForKey:@"error_msg"]];
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Error" message:errorStr delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
        [alert release];  
    }
    email.text=nil;
    password.text=nil;
}
         
- (void)profileApiCallFailed:(NSError *)error {
             
    UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Error" message:[error localizedDescription] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];
    [alert release]; 
    email.text=nil;
    password.text=nil;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {	
	
	[textField resignFirstResponder];
	return YES;
}


- (void)viewDidUnload {
    
    [super viewDidUnload];
}

- (void)viewWillAppear:(BOOL)animated {
    
    [super viewWillAppear:animated];
    self.navigationController.navigationBar.hidden = NO;
}

- (void)viewDidAppear:(BOOL)animated {
    
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated {
    
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated {
    
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
